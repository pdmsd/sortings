package com.cg.ams.client;

import java.util.Scanner;

import com.cg.ams.entities.TraineeDetails;
import com.cg.ams.service.TraineeService;
import com.cg.ams.service.TraineeServiceImpl;

public class Client {

	public static void main(String[] args) {
		
		TraineeService service = new TraineeServiceImpl();
		String trainee_name;
		 String module_name;
		int Mpt_marks;
		 int mtt_marks;
		int assignment_marks;
		 int total;
		 
		 TraineeDetails  td = new TraineeDetails();
		 Scanner scanner = new Scanner(System.in);
		 
		 System.out.println("Enter Trainee_Name");
		 trainee_name=scanner.next();
		 td.setTrainee_name(trainee_name);
		 
		 System.out.println("Enter module_name");
		 module_name=scanner.next();
		 td.setModule_name(module_name);
		 
		 System.out.println("Enter Mpt_marks");
		 Mpt_marks=scanner.nextInt();
		 td.setMpt_marks(Mpt_marks);
		 
		 System.out.println("Enter mtt_marks");
		 mtt_marks=scanner.nextInt();
		 td.setMtt_marks(mtt_marks);
		 
		 System.out.println("Enter assignment_marks");
		 assignment_marks=scanner.nextInt();
		 td.setAssignment_marks(assignment_marks);
		 
		 total = Mpt_marks+mtt_marks+assignment_marks;
		 td.setTotal(total);
		 
		 service.addDetails(td);
		 System.out.println("Data inserted Successfully");
		 

	}

}
