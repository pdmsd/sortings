package com.cg.ams.dao;


import java.util.List;

import com.cg.ams.entities.TraineeDetails;

public interface TraineeDao {
	
	public abstract void addDetails(TraineeDetails  td);
	public abstract void beginTransaction();
	public abstract void commitTransaction();

}
