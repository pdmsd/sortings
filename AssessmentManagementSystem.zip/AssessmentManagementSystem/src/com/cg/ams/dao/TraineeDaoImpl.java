package com.cg.ams.dao;

import javax.persistence.EntityManager;
import com.cg.ams.entities.TraineeDetails;

public class TraineeDaoImpl implements TraineeDao {

	private EntityManager entityManager;
	
	public TraineeDaoImpl() {
		entityManager =JPAUtil.getEntityManager();
	}

	
	@Override
	public void addDetails(TraineeDetails td) {
		 entityManager.persist(td);
	}



	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}


	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

}
