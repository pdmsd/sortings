package com.cg.ams.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Trainee_Details")

public class TraineeDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int details_id;
	private String trainee_name;
	private String module_name;
	private int Mpt_marks;
	private int mtt_marks;
	private int assignment_marks;
	private int total;
	public int getDetails_id() {
		return details_id;
	}
	public void setDetails_id(int details_id) {
		this.details_id = details_id;
	}
	public String getTrainee_name() {
		return trainee_name;
	}
	public void setTrainee_name(String trainee_name) {
		this.trainee_name = trainee_name;
	}
	public String getModule_name() {
		return module_name;
	}
	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}
	public int getMpt_marks() {
		return Mpt_marks;
	}
	public void setMpt_marks(int mpt_marks) {
		Mpt_marks = mpt_marks;
	}
	public int getMtt_marks() {
		return mtt_marks;
	}
	public void setMtt_marks(int mtt_marks) {
		this.mtt_marks = mtt_marks;
	}
	public int getAssignment_marks() {
		return assignment_marks;
	}
	public void setAssignment_marks(int assignment_marks) {
		this.assignment_marks = assignment_marks;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Trainee_Details [details_id=" + details_id + ", trainee_name="
				+ trainee_name + ", module_name=" + module_name
				+ ", Mpt_marks=" + Mpt_marks + ", mtt_marks=" + mtt_marks
				+ ", assignment_marks=" + assignment_marks + ", total=" + total
				+ "]";
	}
	
	
	
}
