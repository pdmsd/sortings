package com.cg.ams.service;

import com.cg.ams.entities.TraineeDetails;

public interface TraineeService {

	public abstract void addDetails(TraineeDetails td);
}
