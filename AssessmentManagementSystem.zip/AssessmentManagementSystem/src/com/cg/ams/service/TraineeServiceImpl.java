package com.cg.ams.service;

import com.cg.ams.dao.TraineeDao;
import com.cg.ams.dao.TraineeDaoImpl;
import com.cg.ams.entities.TraineeDetails;

public class TraineeServiceImpl implements TraineeService {

	private TraineeDao dao;
	
	public TraineeServiceImpl() {
		dao = new TraineeDaoImpl();
	}

	@Override
	public void addDetails(TraineeDetails td) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.addDetails(td);
		dao.commitTransaction();
		
	}
	
	
}
